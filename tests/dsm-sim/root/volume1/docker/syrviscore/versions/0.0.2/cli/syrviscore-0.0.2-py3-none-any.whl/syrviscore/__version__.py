"""SyrvisCore version information."""

__version__ = "0.0.2"
__author__ = "Kevin Tegtmeier"
__description__ = "Self-hosted infrastructure platform for Synology NAS"
